# Reachly — KI-Marketing für deinen Shop

KI-gestütztes Marketing-Tool mit 7 Modulen (Content, Email, Social, SEO, Ads, Strategie).

## Deploy auf Vercel

### 1. Repository anlegen
```bash
git init
git add .
git commit -m "Initial commit"
gh repo create reachly --public --push
```

### 2. Auf Vercel deployen
```bash
npx vercel --yes
```

### 3. API-Key als Environment Variable setzen
Im Vercel Dashboard → Settings → Environment Variables:
```
Name:  ANTHROPIC_API_KEY
Value: sk-ant-...
```
Dann neu deployen:
```bash
npx vercel --prod
```

## Projektstruktur
```
reachly/
├── public/
│   └── index.html      # Frontend
├── api/
│   └── generate.js     # Serverless Proxy (hält API-Key sicher)
├── vercel.json         # Routing
└── README.md
```

## Lokaler Test
```bash
npx vercel dev
```
Setzt voraus: ANTHROPIC_API_KEY in `.env.local`
